-------------------------------------------------------------------------------
-- Module    :  CCO.Aux
-- Copyright :  (c) 2012 Marcelo Sousa 

module CCO.Aux where

import CCO.Component             (Component (..), component, printer)
import CCO.Feedback              (Feedback (..), runFeedback)
import CCO.Tree                  (ATerm, Tree (toTree, fromTree), parser)

(<+>) :: (Tree b) => Component b [a] -> Component b [a] -> Component b [a]
(C f) <+> (C g) = C $ \doc -> do 
  (f doc) <++> (g doc)
  
(<++>) :: Feedback [a] -> Feedback [a] -> Feedback [a]
(Fail l1) <++> (Fail l2) = Fail (l1++l2)
(Fail l1) <++> (Succeed l2 s) = Succeed (l1++l2) s
(Succeed l1 s) <++> (Fail l2) = Succeed (l1++l2) s
(Succeed l1 s1) <++> (Succeed l2 s2) = Succeed (l1++l2) (s1++s2)
